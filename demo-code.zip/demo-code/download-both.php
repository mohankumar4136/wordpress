<div align="center"><center>

<table border="0" width="60%">
  <tr>
    <td width="50%"><?php include("/home/t/h/thedemosite/public_html/download.php"); ?></td>
    <td width="50%"><?php include("/home/t/h/thedemosite/public_html/phpformmailer/download.php"); ?></td>
  </tr>
</table>
</center></div>
