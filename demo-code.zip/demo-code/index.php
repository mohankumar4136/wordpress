<?php
$page_title="FREE example PHP code and online MySQL database - example username password protected site";
$page_keywords="example PHP code,free demo username and password example,PHP scripts,PHP hosting, free PHP code";
$page_desc="FREE example PHP code and a MySQL database. The example is a username and password protected site example";

include("header.inc");
?>
<center><big><strong>1. Home </strong></big></center>
</p>

<p align="center">Follow the links above, in sequence, for an example of a username &amp;
password login web based system, developed using PHP, JavaScript and a MySQL database.</p>

<p align="center">All files on this site are generated using a default header and footer
using &lt;?php include(&quot;afilename.inc&quot;); ?&gt;<font SIZE="1" COLOR="#000000">&nbsp;
</font>This page you are viewing is generated from the following three files:</p>
<div align="center"><center>

<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%"><p align="center"><small><strong>index.php</strong></small>

    <div align="left" style="border:solid 2px #0000FF; background:#EAEDFC; color:#000000; padding:2px; width:800px; height:300px; overflow:auto;">
        <?php show_source("index.php"); ?>
      </div>
      <p align="center"></td>
  </tr>
  <tr>
    <td width="100%"><div align="center"><center><table border="0" width="641" cellspacing="1"
    cellpadding="0" bgcolor="#000000">
    </table>
    </center></div>

<br><br>
<strong>header.inc</strong></p>

<div align="left" style="border:solid 2px #0000FF; background:#EAEDFC; color:#000000; padding:2px; width:800px; height:300px; overflow:auto;">
  <?php show_source("header.inc"); ?>
</div>
<p align="center"><br>
</p>
<p align="center"><strong>footer.inc</strong></p>
<div align="left" style="border:solid 2px #0000FF; background:#EAEDFC; color:#000000; padding:2px; width:800px; height:300px; overflow:auto;">
  <?php show_source("footer.inc"); ?>
</div>




        </td>
  </tr>
</table>
</center></div>

<p align="center">You can <a href="demo-code.zip">download the free zip here</a> which contains all the pages.
</p>
<?php include("footer.inc"); ?>