To setup on your own server:

----------------------------


1. unzip files 



2. edit the file:  config.php
   add your own details (database name, database username and password)




3. upload to your server (to a new folder if required)




4. Open the URL in your browser. 
